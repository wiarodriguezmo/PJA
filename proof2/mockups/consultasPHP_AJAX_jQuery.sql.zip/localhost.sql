-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-10-2012 a las 12:49:46
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tutosWeb`
--
CREATE DATABASE `tutosWeb` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `tutosWeb`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuarios`
--

CREATE TABLE `tbl_usuarios` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único de usuario',
  `usr_nombre` varchar(120) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre completo del usuario',
  `usr_puesto` varchar(80) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Puesto que desempeña el usuario',
  `usr_nick` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'NickName de usuario',
  `usr_status` enum('Activo','Suspendido') COLLATE utf8_unicode_ci NOT NULL COMMENT 'Status de la cuenta de usuario',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de datos usuarios' AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tbl_usuarios`
--

INSERT INTO `tbl_usuarios` VALUES(1, 'Luis Fernando Cázares', 'Desarrollo Web', 'CazaresLuis', 'Activo');
INSERT INTO `tbl_usuarios` VALUES(2, 'Luis Fernando', 'Desarrollo Web', 'Wonka', 'Suspendido');
